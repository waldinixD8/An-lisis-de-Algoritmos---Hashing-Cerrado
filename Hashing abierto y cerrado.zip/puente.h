#include <stdio.h>
#include <stdlib.h>

#include "funcioneshash.h"
#include "hash.h"
#define TAM 11

#include "funcioneshashabi.h"
#include "hashabi.h"
#define RUN_WINDOWS
//#undef RUN_WINDOWS

 
_registro tab[TAM];                                                                                 
_nodo *tabi[TAM];
#include  "sistema.h"