extern void limpiar();
extern void parar();
//extern int leer();