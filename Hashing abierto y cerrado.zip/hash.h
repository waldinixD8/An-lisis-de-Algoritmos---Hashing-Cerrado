extern void hash_cerrado(_registro tab[]);
